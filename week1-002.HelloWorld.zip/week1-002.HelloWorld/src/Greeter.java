public class Greeter {

    public static void main(String[] args) {
        // Write your code here
        System.out.print("Love"); System.out.println("Is"); System.out.println("Infinite");
    }

}